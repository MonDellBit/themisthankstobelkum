---
name: Thêm tính năng
about: Góp ý một ý tưởng cho dự án
title: ''
labels: enhancement
assignees: belivipro9x99

---

## 🎈 góp ý tính năng
---
### 📃 Mô Tả
Một mô tả ngắn gọn và rõ ràng về tính năng mà bạn muốn góp ý

### 🐛 Lỗi Liên Quan
Nếu tính năng này có liên quan tới lỗi nào đó, hãy link vào đây.

### ✏ Nội Dung
Mô tả chi tiết cách mà tính năng bạn góp ý hoạt động

#### Thông tin thêm
Thêm bất kỳ thông tin nào liên quan tại đây.
