---
name: Báo lỗi
about: Báo một lỗi để mình có thể sửa trong thời gian sớm nhất!
title: ''
labels: bug, help wanted
assignees: belivipro9x99

---

## 🐞 báo cáo lỗi
---
### 📃 Mô Tả
Một mô tả ngắn gọn và rõ ràng về lỗi mà bạn gặp

### 🔬 Cách Gây Ra Lỗi
1. Đi tới '...'
2. Nhấn vào '....'
3. Cuộn xuống '....'
4. Lỗi!!!

### 🎯 Hành Vi Dự Kiến
Một mô tả rõ ràng và ngắn gọn về hành vi mà bạn nghĩ nên xảy ra

### 📷 Ảnh Chụp
Nếu có thể, hãy đính kèm một ảnh chụp màn hình tại đây.

### 🌍 Phiên Bản
 - Hệ điều hành: [vd: Windows, Ubuntu, MacOS]
 - Trình duyệt: [vd: Chrome, CocCoc, Edge, Safari]
 - Trình chấm: [vd: Themis v1.9.8 b.2806]

#### Thông tin thêm
Thêm bất kỳ thông tin nào liên quan đến lỗi tại đây.
